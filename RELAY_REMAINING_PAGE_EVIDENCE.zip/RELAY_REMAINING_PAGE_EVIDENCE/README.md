# RELAY — Visual Acceptance Evidence Archive

This archive contains verified full-page and component screenshots of the Relay Autonomous Community Procurement Platform, captured from the live application running on localhost.

---

## 1. Test Missions & Provenance

### English Multi-Product Procurement Mission
* **Workflow ID**: `wf_6e298283-6` (Display Ref: `RUN-6E298283`)
* **Prompt**: `"2 kg rice, 1 kg sugar and 2 packs Maggi"`
* **Products**: Rice (2 kg), Sugar (1 kg), Maggi (2 packs)
* **Resident Reference**: `res_52fb01342ce05e69` (Society: `soc_8e1fd7ab-1`, Pune, Maharashtra)
* **Discovered Suppliers**: 3 candidates (`mock_sup_1`, `mock_sup_2`, `mock_sup_3`)
* **Negotiated Quote**: `Local Agro Wholesale Direct` (Initial: ₹290.71 → Negotiated: ₹288.30, saving ₹2.41)
* **Winning Supplier**: `Community Grain & Oil Depot` (`mock_sup_2`) at lowest overall baseline total of **₹285.65**
* **Financial Proof**: 4-Pillar exact balance at **₹285.65** (Commitment PO = Payment Debit = Resident Allocation = Reconciliation; 0 discrepancies)

### Marathi Open-World Multi-Product Procurement Mission
* **Workflow ID**: `wf_5f0c92df-b` (Display Ref: `RUN-5F0C92DF`)
* **Prompt**: `"मला हार्पिकच्या २ बाटल्या, १ रूम क्लीनर unit आणि ३ फ्रॅग्रन्स स्प्रे unit हवेत."`
* **Products**: Harpic (2 bottles), Room Cleaner (1 unit), Fragrance Spray (3 units)
* **Resident Reference**: `res_52fb01342ce05e69` (Society: `soc_8e1fd7ab-1`, Pune, Maharashtra)
* **Discovered Suppliers**: 3 candidates (`mock_sup_1`, `mock_sup_2`, `mock_sup_3`)
* **Negotiated Quote**: `Local Agro Wholesale Direct` (Initial: ₹418.95 → Negotiated: ₹415.21, saving ₹3.74)
* **Winning Supplier**: `Local Agro Wholesale Direct` (`mock_sup_1`) at lowest overall total of **₹415.21**
* **Financial Proof**: 4-Pillar exact balance at **₹415.21** (Commitment PO = Payment Debit = Resident Allocation = Reconciliation; 0 discrepancies)

---

## 2. Stage Coverage & Accounting

Relay implements 13 canonical workflow stages:
1. `UNDERSTAND`
2. `DISCOVER`
3. `QUALIFY`
4. `QUOTE`
5. `NEGOTIATE`
6. `SELECT`
7. `COMMIT`
8. `PAY`
9. `FULFILL`
10. `VERIFY`
11. `ALLOCATE`
12. `RECONCILE`
13. `COMPLETE`

### Visual Capture Accounting (35 PNG Screenshots Total):
* **Operational & Workspace Screens (13 screenshots)**:
  - `01_Procurement` (2): Dashboard overview & demand batches table.
  - `02_Market` (2): Catalog overview & verified product list.
  - `03_Verification` (1): Operational verification hub console.
  - `04_Allocation` (2): Resident allocation overview & finalized ledger.
  - `05_Settings` (2): Profile overview & mandate capacity / security controls.
  - `06_Login` (2): Email/OAuth login & Twilio-backed phone OTP screen.
  - `07_Onboarding` (2): Society onboarding stepper & full screen.
* **Mission Overview Timelines (2 screenshots)**:
  - `08_Mission_Stages/00_mission_overview_english_wf_6e298283.png`: Complete 13-stage milestone progression for English mission.
  - `08_Mission_Stages/00_mission_overview_marathi_wf_5f0c92df.png`: Complete 13-stage milestone progression for Marathi mission.
* **Dedicated Mission-Stage Screens (20 screenshots)**:
  - 10 distinct stage screens captured per mission × 2 missions:
    1. `Discover` (Stage 02) — 2 screenshots (English & Marathi)
    2. `Qualify` (Stage 03) — 2 screenshots (English & Marathi)
    3. `Negotiation` (Stage 05) — 2 screenshots (English & Marathi)
    4. `Selection` (Stage 06) — 2 screenshots (English & Marathi)
    5. `Commitment` (Stage 07) — 2 screenshots (English & Marathi)
    6. `Payment` (Stage 08) — 2 screenshots (English & Marathi)
    7. `Fulfillment` (Stage 09) — 2 screenshots (English & Marathi)
    8. `Verification` (Stage 10) — 2 screenshots (English & Marathi)
    9. `Allocation` (Stage 11) — 2 screenshots (English & Marathi)
    10. `Reconciliation` (Stage 12) — 2 screenshots (English & Marathi)

*Note on Stages 01, 04, and 13*:
- Stage 01 (`Understand`) and Stage 04 (`Quote`) are visually rendered and inspected on the Mission Overview timeline (`00_mission_overview_...`), and their underlying APIs and extractors are 100% verified via automated test suites.
- Stage 13 (`Complete`) is represented by the Mission Overview screen itself upon terminal verification.

---

## 3. Complete Screenshot Inventory

```
RELAY_REMAINING_PAGE_EVIDENCE/
├── README.md
├── captured-meta.json
├── 01_Procurement/
│   ├── 01_procurement_dashboard_overview.png
│   └── 02_procurement_demand_batches_full.png
├── 02_Market/
│   ├── 01_market_catalog_overview.png
│   └── 02_market_catalog_products_full.png
├── 03_Verification/
│   └── 01_verification_hub_console_full.png
├── 04_Allocation/
│   ├── 01_allocation_overview.png
│   └── 02_allocation_resident_ledger_full.png
├── 05_Settings/
│   ├── 01_resident_profile_overview.png
│   └── 02_mandate_and_security_controls_full.png
├── 06_Login/
│   ├── 01_login_default_email_and_oauth.png
│   └── 02_login_phone_auth_screen.png
├── 07_Onboarding/
│   ├── 01_onboarding_stepper_profile.png
│   └── 02_onboarding_full_screen.png
└── 08_Mission_Stages/
    ├── 00_mission_overview_english_wf_6e298283.png
    ├── 00_mission_overview_marathi_wf_5f0c92df.png
    ├── Discover/
    │   ├── 01_discover_stage_english_wf_6e298283.png
    │   └── 02_discover_stage_marathi_wf_5f0c92df.png
    ├── Qualify/
    │   ├── 01_qualify_stage_english_wf_6e298283.png
    │   └── 02_qualify_stage_marathi_wf_5f0c92df.png
    ├── Negotiation/
    │   ├── 01_negotiation_stage_english_wf_6e298283.png
    │   └── 02_negotiation_stage_marathi_wf_5f0c92df.png
    ├── Selection/
    │   ├── 01_selection_stage_english_wf_6e298283.png
    │   └── 02_selection_stage_marathi_wf_5f0c92df.png
    ├── Commitment/
    │   ├── 01_commitment_stage_english_wf_6e298283.png
    │   └── 02_commitment_stage_marathi_wf_5f0c92df.png
    ├── Payment/
    │   ├── 01_payment_stage_english_wf_6e298283.png
    │   └── 02_payment_stage_marathi_wf_5f0c92df.png
    ├── Fulfillment/
    │   ├── 01_fulfillment_stage_english_wf_6e298283.png
    │   └── 02_fulfillment_stage_marathi_wf_5f0c92df.png
    ├── Verification/
    │   ├── 01_verification_stage_english_wf_6e298283.png
    │   └── 02_verification_stage_marathi_wf_5f0c92df.png
    ├── Allocation/
    │   ├── 01_allocation_stage_english_wf_6e298283.png
    │   └── 02_allocation_stage_marathi_wf_5f0c92df.png
    └── Reconciliation/
        ├── 01_reconciliation_stage_english_wf_6e298283.png
        └── 02_reconciliation_stage_marathi_wf_5f0c92df.png
```

---

## 4. Test Environment

* **Frontend**: Next.js 14.2.35, React 18, Tailwind CSS, Framer Motion (`http://localhost:3000`)
* **Backend**: Node.js v24.16.0, Express 4.19, TypeScript 5.5, Prisma ORM 5.22 (`http://localhost:4000`)
* **Database**: PostgreSQL 16 on `localhost:5432` (`relay_db`)
* **Capture Tool**: Headless Chromium (`puppeteer-core`)
* **Display Configuration**: 1440 × 900 resolution @ 2.0 device scale factor (Retina 2880 × 1800 rendered output)
* **Auth State**: Authenticated session with valid resident token (`relay_session_token`)

---

## 5. Simulated Provider Disclosures

In accordance with strict hackathon safety constraints:
1. **Payments**: Settled through Relay's deterministic `MockPaymentProvider` under resident mandate authorization (`isSimulated: true`). External payment gateways were not charged.
2. **Suppliers & Fulfillment**: Commercial suppliers (`mock_sup_1`, `mock_sup_2`, `mock_sup_3`) and dispatch tracking are simulated with realistic coordinates (Baner, Pune) and deterministic SLA calculations.
3. **SMS / Twilio**: Twilio Verify integration is server-configured (`SMS_PROVIDER=twilio`). Live SMS dispatches were blocked during automated headless capture to prevent carrier spam and credential leaks.

---

## 6. Known Contexts & Clarifications

* **Negotiation vs Selection Totals**:
  - In English mission `wf_6e298283-6`, the Negotiation timeline shows Round 4 settling a quote with `Local Agro Wholesale Direct` at **₹288.30** (saved ₹2.41).
  - The subsequent Selection stage evaluated all 3 suppliers and selected `Community Grain & Oil Depot` at **₹285.65** because its baseline price was lower than the negotiated offer.
  - The authoritative procurement order amount is **₹285.65**, identically conserved across all financial pillars (Commitment, Payment, Allocation, Reconciliation).
